pdf(file='cl1_vs_pFH.pdf',width=4.5,height=4.5);
gstable=read.table('cl1_vs_pFH.gene_summary.txt',header=T)
# 
#
# parameters
# Do not modify the variables beginning with "__"

# gstablename='__GENE_SUMMARY_FILE__'
startindex=3
# outputfile='__OUTPUT_FILE__'
targetgenelist=c("Nf2","Romo1","Syvn1","Qrich1","Gmppb","Phb2","Eif2b4","Fau","Ccdc84","Polr2j")
# samplelabel=sub('.\\w+.\\w+$','',colnames(gstable)[startindex]);
samplelabel='ERS3957545.sample,ERS3957544.sample,ERS3957548.sample_vs_ERS3957547.sample,ERS3957546.sample,ERS3957549.sample neg.'


# You need to write some codes in front of this code:
# gstable=read.table(gstablename,header=T)
# pdf(file=outputfile,width=6,height=6)


# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")

######
# function definition

plotrankedvalues<-function(val, tglist, ...){
  
  plot(val,log='y',ylim=c(max(val),min(val)),type='l',lwd=2, ...)
  if(length(tglist)>0){
    for(i in 1:length(tglist)){
      targetgene=tglist[i];
      tx=which(names(val)==targetgene);ty=val[targetgene];
      points(tx,ty,col=colors[(i %% length(colors)) ],cex=2,pch=20)
      # text(tx+50,ty,targetgene,col=colors[i])
    }
    legend('topright',tglist,pch=20,pt.cex = 2,cex=1,col=colors)
  }
}



plotrandvalues<-function(val,targetgenelist, ...){
  # choose the one with the best distance distribution
  
  mindiffvalue=0;
  randval=val;
  for(i in 1:20){
    randval0=sample(val)
    vindex=sort(which(names(randval0) %in% targetgenelist))
    if(max(vindex)>0.9*length(val)){
      # print('pass...')
      next;
    }
    mindiffind=min(diff(vindex));
    if (mindiffind > mindiffvalue){
      mindiffvalue=mindiffind;
      randval=randval0;
      # print(paste('Diff: ',mindiffvalue))
    }
  }
  plot(randval,log='y',ylim=c(max(randval),min(randval)),pch=20,col='grey', ...)
  
  if(length(targetgenelist)>0){
    for(i in 1:length(targetgenelist)){
      targetgene=targetgenelist[i];
      tx=which(names(randval)==targetgene);ty=randval[targetgene];
      points(tx,ty,col=colors[(i %% length(colors)) ],cex=2,pch=20)
      text(tx+50,ty,targetgene,col=colors[i])
    }
  }
  
}




# set.seed(1235)



pvec=gstable[,startindex]
names(pvec)=gstable[,'id']
pvec=sort(pvec);

plotrankedvalues(pvec,targetgenelist,xlab='Genes',ylab='RRA score',main=paste('Distribution of RRA scores in \\n',samplelabel))

# plotrandvalues(pvec,targetgenelist,xlab='Genes',ylab='RRA score',main=paste('Distribution of RRA scores in \\n',samplelabel))


pvec=gstable[,startindex+1]
names(pvec)=gstable[,'id']
pvec=sort(pvec);

plotrankedvalues(pvec,targetgenelist,xlab='Genes',ylab='p value',main=paste('Distribution of p values in \\n',samplelabel))

# plotrandvalues(pvec,targetgenelist,xlab='Genes',ylab='p value',main=paste('Distribution of p values in \\n',samplelabel))



# you need to write after this code:
# dev.off()






# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(16.373078958589648,37.221550317376746,9.794472856049516,28.753305258746657,16.476418950427,22.064284305933278),c(505.55957934284424,435.8918170218145,617.6686299581194,219.50408842142528,192.7241549017856,192.84843851339178),c(285.06413303602875,242.69938051722386,314.67929676873746,85.50881079310697,121.30670288448187,75.66194719874933),c(660.2378955275575,923.3389785125034,464.8395212952508,146.3549113594307,150.5342987891289,110.76300472466858),c(435.76070669960205,296.27299698304756,364.77703976135086,58.608007775633425,73.20839174163585,51.60480907078706))
targetgene="Nf2"
collabel=c("ERS3957547.sample","ERS3957546.sample","ERS3957549.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(417.0491037181184,498.7677108672764,663.8980645121206,106.26808954011577,127.68903122010502,123.68136591971617),c(182.24226532548258,267.2869081035707,315.9063214018535,65.56277787056804,48.304355474236395,29.862033581628506),c(177.87950919997814,218.61296649469176,191.1097160688534,93.41267557212788,39.0432892629578,9.1302097881857),c(367.8399639922601,372.4064776877494,361.32734405492675,93.71700723507331,75.13918582603611,65.80041186392428),c(398.6079898211113,577.186874572933,279.3484428050346,432.0795060131192,265.7216396874333,275.7815386772517))
targetgene="Romo1"
collabel=c("ERS3957547.sample","ERS3957546.sample","ERS3957549.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(274.3692707334271,300.930205281967,121.78299142406296,24.813552543664308,15.30756984189373,15.220634611407192),c(116.69144572365308,150.1001045841889,200.26010037777388,35.71328001462497,22.427421639307767,3.967824087411014),c(79.48905495888755,72.02191103956491,62.99195515420874,5.570913736383556,2.916309669710192,1.2569231233539946),c(158.91753965758815,142.59805967846566,193.0080104886871,30.27344558535688,9.343979491650678,20.04482765256185),c(349.14919658928864,405.1337354389105,190.25968283990179,84.3238460261435,138.6680268845072,97.78745375383495))
targetgene="Syvn1"
collabel=c("ERS3957547.sample","ERS3957546.sample","ERS3957549.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(286.41951344319034,133.160262251167,144.9066523019776,151.63735995572563,111.50066428845123,66.35806931502637),c(676.5840985237929,705.2037130301,430.2914624457732,291.5907334212667,182.62308171194235,182.1634662268084),c(234.43607703719184,149.13128564539844,211.5436144982343,74.88983375736134,77.39189168733981,30.631751083249167),c(571.3851272607085,582.4150205238564,499.3291028094231,281.9089020214164,240.72784184997667,226.07889285874413),c(451.42534977996013,500.15705146812365,453.63325538601754,179.97347646568718,206.28224266451676,131.50198318856295))
targetgene="Qrich1"
collabel=c("ERS3957547.sample","ERS3957546.sample","ERS3957549.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(78.32938438937947,44.3040093683486,108.85582976857435,13.877958752826347,9.571430613019437,2.3211083828168344),c(125.78204049248902,23.99232507332109,76.21447770218431,2.2383804440042496,2.9704439833508594,4.8207635643118865),c(135.85760445958763,166.17411513851368,123.48285074172084,14.325634841627195,16.172417242688013,10.534261122014865),c(60.77840199507867,53.30113127084402,63.43508043090896,1.9399297181370163,1.155172660192001,0.17854679867821807),c(145.93316842668622,91.47073934203667,117.32410506881706,0.5969014517344665,0.4950739972251433,0.0))
targetgene="Gmppb"
collabel=c("ERS3957547.sample","ERS3957546.sample","ERS3957549.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(430.4479648677483,363.72930122442745,230.9411646713978,51.716257638255925,29.717009112535784,31.22256401574872),c(327.8080992865059,322.6323099945386,318.4421244708227,23.88286627737109,22.823767682012633,24.207494185383524),c(94.49330739049762,157.34795709620232,106.3137301419488,96.15744417385503,96.39264634863959,72.25254458909185),c(78.16850199212251,74.1743598887938,82.71651886614009,47.299109617082124,7.418145961956668,12.683127760395312),c(339.6818661393144,399.82704058164217,253.4562459678716,97.9048222573038,140.77270174952122,178.10104759220718))
targetgene="Phb2"
collabel=c("ERS3957547.sample","ERS3957546.sample","ERS3957549.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(153.24607775764488,148.72515144882564,128.71778456368904,14.474860204560812,14.52217058527087,12.141182310118827),c(67.11625674857618,80.42881700715594,32.025477499099665,1.3430282664025497,0.0,0.0),c(127.40713145492427,47.43937003133943,137.80193443122212,48.498242953425404,35.31527846872689,30.35295577529707),c(17.063455105570217,5.998081268330273,39.10803502293902,0.0,0.0,0.0),c(106.60596713575296,73.8854556235229,119.63363469615597,8.058169598415299,26.733995850157736,12.498275907475263))
targetgene="Eif2b4"
collabel=c("ERS3957547.sample","ERS3957546.sample","ERS3957549.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(240.17775039231887,245.86304263732848,294.2327548113802,85.74373538252061,133.8890032553468,56.519252290284435),c(524.38304564968,616.3067506800394,356.1830127677235,137.0145256025687,121.86561575060936,219.2705562541187),c(395.55165311815125,486.35147615056286,657.5910341240215,342.5656124275612,528.5847916832031,384.9004587651231),c(172.34295547260461,228.0992469859066,150.56714598519864,74.19326894387783,46.08018689272807,17.33054857891771),c(645.418971532113,548.3966377742925,502.71429601489524,178.5763605360977,227.75541462390953,172.35165237268993))
targetgene="Fau"
collabel=c("ERS3957547.sample","ERS3957546.sample","ERS3957549.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(57.618804600045515,62.39109114204167,48.40327041278503,79.16085351820301,85.15272763612984,4.399293308256082),c(90.84559090037237,142.3210048995329,155.98961286974702,27.09074032653676,59.75672690620442,29.30964033802705),c(116.74520721634019,66.73005787814375,150.16953948613752,7.77790229583041,4.779513610746704,6.244519411929388),c(412.3192341165751,240.15701262731162,414.42567307109124,210.4205530150907,259.2025478476814,160.79741713392934),c(270.7977884488438,232.57797308145953,247.6155577303687,14.92416608712157,45.43993982038098,48.96194910075466))
targetgene="Ccdc84"
collabel=c("ERS3957547.sample","ERS3957546.sample","ERS3957549.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(100.91814876722955,89.15329885199996,109.47170433586473,8.804296413083382,20.133009220489157,14.8193842902921),c(39.32720129093326,68.160014412844,69.90176338745793,4.178310162141266,3.7955673120594313,25.35364541230696),c(134.72004078588296,119.4163452513027,71.28748116386129,28.35281895738716,4.620690640768004,29.817315379262414),c(97.18043955362847,63.797773490421996,80.06369374774917,12.982606575224647,34.3251304742766,15.355024686326752),c(173.07218749935507,88.74433876552291,89.30181225710484,16.713240648565066,15.182269248237725,27.49620699644558))
targetgene="Polr2j"
collabel=c("ERS3957547.sample","ERS3957546.sample","ERS3957549.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}



# 
#
# parameters
# Do not modify the variables beginning with "__"

# gstablename='__GENE_SUMMARY_FILE__'
startindex=9
# outputfile='__OUTPUT_FILE__'
targetgenelist=c("Pfkl","Ube2m","Ogdh","Glrx5","Hira","Pfkfb1","Sdhb","Sdha","Dlst","Npepps")
# samplelabel=sub('.\\w+.\\w+$','',colnames(gstable)[startindex]);
samplelabel='ERS3957545.sample,ERS3957544.sample,ERS3957548.sample_vs_ERS3957547.sample,ERS3957546.sample,ERS3957549.sample pos.'


# You need to write some codes in front of this code:
# gstable=read.table(gstablename,header=T)
# pdf(file=outputfile,width=6,height=6)


# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")

######
# function definition

plotrankedvalues<-function(val, tglist, ...){
  
  plot(val,log='y',ylim=c(max(val),min(val)),type='l',lwd=2, ...)
  if(length(tglist)>0){
    for(i in 1:length(tglist)){
      targetgene=tglist[i];
      tx=which(names(val)==targetgene);ty=val[targetgene];
      points(tx,ty,col=colors[(i %% length(colors)) ],cex=2,pch=20)
      # text(tx+50,ty,targetgene,col=colors[i])
    }
    legend('topright',tglist,pch=20,pt.cex = 2,cex=1,col=colors)
  }
}



plotrandvalues<-function(val,targetgenelist, ...){
  # choose the one with the best distance distribution
  
  mindiffvalue=0;
  randval=val;
  for(i in 1:20){
    randval0=sample(val)
    vindex=sort(which(names(randval0) %in% targetgenelist))
    if(max(vindex)>0.9*length(val)){
      # print('pass...')
      next;
    }
    mindiffind=min(diff(vindex));
    if (mindiffind > mindiffvalue){
      mindiffvalue=mindiffind;
      randval=randval0;
      # print(paste('Diff: ',mindiffvalue))
    }
  }
  plot(randval,log='y',ylim=c(max(randval),min(randval)),pch=20,col='grey', ...)
  
  if(length(targetgenelist)>0){
    for(i in 1:length(targetgenelist)){
      targetgene=targetgenelist[i];
      tx=which(names(randval)==targetgene);ty=randval[targetgene];
      points(tx,ty,col=colors[(i %% length(colors)) ],cex=2,pch=20)
      text(tx+50,ty,targetgene,col=colors[i])
    }
  }
  
}




# set.seed(1235)



pvec=gstable[,startindex]
names(pvec)=gstable[,'id']
pvec=sort(pvec);

plotrankedvalues(pvec,targetgenelist,xlab='Genes',ylab='RRA score',main=paste('Distribution of RRA scores in \\n',samplelabel))

# plotrandvalues(pvec,targetgenelist,xlab='Genes',ylab='RRA score',main=paste('Distribution of RRA scores in \\n',samplelabel))


pvec=gstable[,startindex+1]
names(pvec)=gstable[,'id']
pvec=sort(pvec);

plotrankedvalues(pvec,targetgenelist,xlab='Genes',ylab='p value',main=paste('Distribution of p values in \\n',samplelabel))

# plotrandvalues(pvec,targetgenelist,xlab='Genes',ylab='p value',main=paste('Distribution of p values in \\n',samplelabel))



# you need to write after this code:
# dev.off()






# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(119.6085560452122,144.3663204002476,173.9957331384774,585.31443941418,552.1019898160249,509.4220590270037),c(110.35218740377866,128.97464040150822,98.87628654769078,580.4902445717917,589.7385099981067,604.1828647493165),c(42.393096645959126,70.84405261472982,25.223927072225624,359.04853992931925,333.6848881129209,360.7093851311289),c(62.056187122899736,38.00728470172363,57.521571116440356,168.89462922689708,183.10907273708858,157.32023282536622),c(30.222058644248808,28.181052627463696,26.34252598123879,201.64424379463327,183.41511836117337,215.24225255696646))
targetgene="Pfkl"
collabel=c("ERS3957547.sample","ERS3957546.sample","ERS3957549.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(150.0647890092243,64.60161310826768,92.13592229555124,187.20965892419045,187.76879685457718,235.07681163154186),c(71.50460887852768,41.75208273550059,25.028927435377867,287.83883663085544,226.8360552032098,236.1499960884973),c(92.1191822872009,87.31760612104823,54.232209122253316,509.2332848685714,418.49825163636376,394.9262051803025),c(75.09591655326463,67.15193454202425,74.17901093469075,126.64257031048996,177.94104298492337,175.14289459294974),c(1.6030992648138858,4.087382407498273,3.0505783087083884,42.972113794033866,25.503125381664493,16.18720423238324),c(125.80622920592681,163.37047721373756,135.44883903444298,270.60091688655876,266.2429651971795,265.4305418709021),c(48.42382242707199,25.774709493850462,81.25629153704764,214.18343223582394,192.05306004890576,290.1092016633842),c(76.19097204848565,75.6668703119334,38.02910798450063,258.60549786274737,248.94941753643866,213.23066341869023))
targetgene="Ube2m"
collabel=c("ERS3957547.sample","ERS3957546.sample","ERS3957549.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(42.79676106696069,96.93230703767077,48.9269503650515,145.5732015568082,91.72408302549796,148.77990594451768),c(107.47224632402626,123.0744420550593,149.867244660941,444.6569394582438,422.49903998284765,303.38330565584164),c(48.045697933338516,34.23189652386158,31.13431388420946,208.72743262673077,189.26920165299035,235.73585213677777),c(49.59585158272777,85.4494292748634,72.21830550105432,215.97413865777597,278.73468024050857,211.83660569656294),c(79.9876763203825,45.846463186211466,56.4549177175174,331.95907684784464,325.9747286558222,281.45513698390175))
targetgene="Ogdh"
collabel=c("ERS3957547.sample","ERS3957546.sample","ERS3957549.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(146.88733266249315,148.16471240160953,144.76370123616883,552.2587849487072,503.7148520521226,486.21261446515075),c(85.18030591924607,83.80394686749867,105.46032702807658,210.2065001569307,217.29714913167132,324.1593899757088),c(40.71795963796118,61.26565184793606,50.639787249847224,165.14061554255227,155.87708468949162,158.531438317889),c(45.036829924847865,52.65209962092924,31.24983819656515,253.9475329718241,284.4254578005011,206.28146404748847),c(5.747686281546341,9.36136377156896,12.949681436341077,53.65665179864855,44.62544340138529,40.75794424829614))
targetgene="Glrx5"
collabel=c("ERS3957547.sample","ERS3957546.sample","ERS3957549.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(176.51207587125572,185.3951981969273,185.2595653961446,697.8939812236955,714.5215461326977,528.174742337454),c(108.9265250762107,134.53687136682726,135.86617470940806,540.3642374875857,495.0270106497138,633.865398335382),c(83.90767367617704,57.47591393997956,97.53466915044882,176.0996931555729,97.75230182702157,194.29902012158922),c(56.37133168640475,55.09375795823959,51.0974808066541,313.7959218102014,244.03784241898526,283.6482262206251),c(220.77734775080125,157.57751973946873,145.15166422175295,363.43748249081534,366.07033352157845,448.78693070838824))
targetgene="Hira"
collabel=c("ERS3957547.sample","ERS3957546.sample","ERS3957549.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(64.206312464856,90.44980403757584,43.926109562138976,240.53752929356548,254.37609421760038,271.4037311730909),c(63.9630301925935,38.1906843480167,44.95809623385648,281.637888790855,306.78384915699326,308.5740834955083),c(78.65441539979567,58.48346048275652,77.99128358276302,330.0580008109542,373.4222267785416,295.6396111648607),c(86.02937470491307,74.6313135326894,71.63176927659971,210.37023053628207,236.99797087883692,203.35086904249383))
targetgene="Pfkfb1"
collabel=c("ERS3957547.sample","ERS3957546.sample","ERS3957549.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(77.72891725191238,48.79280086972031,28.312314283049687,296.8818664132802,255.22200881530455,277.1818219178746),c(96.2895949622138,100.09241862089918,76.7561776097213,136.6913002267872,128.9066128480211,156.41779611540215),c(41.67730501214132,28.33081566727777,15.595356217130353,119.40684430781639,112.85764558170723,107.86423290633971),c(113.34406361727271,57.33086645162091,123.57668139790609,263.80021707420644,324.84062225608056,313.1839464535436),c(94.6478452737031,64.73120522829116,84.51136236319691,302.7494931095432,277.11349964566426,292.7527221194147))
targetgene="Sdhb"
collabel=c("ERS3957547.sample","ERS3957546.sample","ERS3957549.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(35.85402629790111,25.727590486305957,40.55823313073323,25.748346678271826,38.78436700733847,30.789090808471606),c(141.19599838141318,182.99607681564925,79.78485658391962,413.1538512399444,501.2963010810274,502.8312229313942),c(35.99414220311596,58.19624815083231,40.08179967011449,225.56535033571953,181.3007212278069,221.7284863807582),c(189.13581342772892,229.6481031897407,140.64152297563086,294.85437176719483,386.77280987985023,490.3218536750977),c(54.23541446439676,90.0771305881243,51.041154122246056,243.98644501911278,227.98870820089562,205.7911437933826))
targetgene="Sdha"
collabel=c("ERS3957547.sample","ERS3957546.sample","ERS3957549.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(77.34246588048781,72.01197434707916,72.35573181732836,190.2768872864559,298.9371338561235,197.9398187303977),c(167.0288397066334,265.89480118914435,224.62863644329596,161.0596381862657,231.16265139002246,208.8341117589118),c(29.107256631504598,54.18078371541422,33.265063169293086,145.9682752455119,118.99722665413633,148.61276013010723),c(51.991806959696994,54.92740403110946,79.5840401776933,353.79464654652026,305.5519642290416,386.6591923243283),c(34.45283197668833,54.37961069540736,70.72421380316248,277.3961869671591,229.00782872025576,229.0134326941122))
targetgene="Dlst"
collabel=c("ERS3957547.sample","ERS3957546.sample","ERS3957549.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(95.98464332337106,111.55255455685118,160.74093336019942,313.15905790994935,340.49731523028163,352.0694631047789),c(76.41307463273849,57.86328322948379,28.04331361558345,98.31127478892304,83.39704303125556,73.35809728045169),c(214.10121658332417,137.25462038464443,125.10105728926456,516.7358201092413,385.19687502709087,452.3234449225094),c(167.3346917156378,161.96372513553774,173.6148001120748,347.32101228436767,356.97428124856793,412.0641224110217),c(225.60185568371764,312.639190226552,260.9224114670749,609.452420937338,480.1483439349888,558.2363364948966))
targetgene="Npepps"
collabel=c("ERS3957547.sample","ERS3957546.sample","ERS3957549.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}



dev.off()
Sweave("cl1_vs_pFH_summary.Rnw");
library(tools);

texi2dvi("cl1_vs_pFH_summary.tex",pdf=TRUE);

