pdf(file='cl1_vs_flfl.pdf',width=4.5,height=4.5);
gstable=read.table('cl1_vs_flfl.gene_summary.txt',header=T)
# 
#
# parameters
# Do not modify the variables beginning with "__"

# gstablename='__GENE_SUMMARY_FILE__'
startindex=3
# outputfile='__OUTPUT_FILE__'
targetgenelist=c("Nf2","Cnot2","Arid4a","Fbxw7","Ralgapb","Foxa2","Slc33a1","Kdm2b","Qrich1","Cdkn2a")
# samplelabel=sub('.\\w+.\\w+$','',colnames(gstable)[startindex]);
samplelabel='ERS3957545.sample,ERS3957544.sample,ERS3957548.sample_vs_ERS3957541.sample,ERS3957543.sample,ERS3957542.sample neg.'


# You need to write some codes in front of this code:
# gstable=read.table(gstablename,header=T)
# pdf(file=outputfile,width=6,height=6)


# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")

######
# function definition

plotrankedvalues<-function(val, tglist, ...){
  
  plot(val,log='y',ylim=c(max(val),min(val)),type='l',lwd=2, ...)
  if(length(tglist)>0){
    for(i in 1:length(tglist)){
      targetgene=tglist[i];
      tx=which(names(val)==targetgene);ty=val[targetgene];
      points(tx,ty,col=colors[(i %% length(colors)) ],cex=2,pch=20)
      # text(tx+50,ty,targetgene,col=colors[i])
    }
    legend('topright',tglist,pch=20,pt.cex = 2,cex=1,col=colors)
  }
}



plotrandvalues<-function(val,targetgenelist, ...){
  # choose the one with the best distance distribution
  
  mindiffvalue=0;
  randval=val;
  for(i in 1:20){
    randval0=sample(val)
    vindex=sort(which(names(randval0) %in% targetgenelist))
    if(max(vindex)>0.9*length(val)){
      # print('pass...')
      next;
    }
    mindiffind=min(diff(vindex));
    if (mindiffind > mindiffvalue){
      mindiffvalue=mindiffind;
      randval=randval0;
      # print(paste('Diff: ',mindiffvalue))
    }
  }
  plot(randval,log='y',ylim=c(max(randval),min(randval)),pch=20,col='grey', ...)
  
  if(length(targetgenelist)>0){
    for(i in 1:length(targetgenelist)){
      targetgene=targetgenelist[i];
      tx=which(names(randval)==targetgene);ty=randval[targetgene];
      points(tx,ty,col=colors[(i %% length(colors)) ],cex=2,pch=20)
      text(tx+50,ty,targetgene,col=colors[i])
    }
  }
  
}




# set.seed(1235)



pvec=gstable[,startindex]
names(pvec)=gstable[,'id']
pvec=sort(pvec);

plotrankedvalues(pvec,targetgenelist,xlab='Genes',ylab='RRA score',main=paste('Distribution of RRA scores in \\n',samplelabel))

# plotrandvalues(pvec,targetgenelist,xlab='Genes',ylab='RRA score',main=paste('Distribution of RRA scores in \\n',samplelabel))


pvec=gstable[,startindex+1]
names(pvec)=gstable[,'id']
pvec=sort(pvec);

plotrankedvalues(pvec,targetgenelist,xlab='Genes',ylab='p value',main=paste('Distribution of p values in \\n',samplelabel))

# plotrandvalues(pvec,targetgenelist,xlab='Genes',ylab='p value',main=paste('Distribution of p values in \\n',samplelabel))



# you need to write after this code:
# dev.off()






# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(6.120924784053836,13.637300791698518,60.602919953274615,28.753305258746657,16.476418950427,22.064284305933278),c(433.659214911056,364.387015210346,1300.1252757360544,219.50408842142528,192.7241549017856,192.84843851339178),c(160.46175804161624,351.0994180186875,528.1689354185154,85.50881079310697,121.30670288448187,75.66194719874933),c(497.2267125440638,932.459061374887,596.0337041071743,146.3549113594307,150.5342987891289,110.76300472466858),c(166.44321777492542,342.7799419704498,269.10820310953994,58.608007775633425,73.20839174163585,51.60480907078706))
targetgene="Nf2"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(36.43040004967807,57.44553177880036,36.809128202386596,0.3772136602677117,0.3772136602677117,2.7344738613149615),c(183.46999392006805,257.02275327956175,134.2831468009657,37.76324945409453,28.821009985667168,57.02546035451669),c(86.23927182290252,307.9962829254182,221.24223142540336,39.48756522116572,19.0493525714174,19.164117871010824),c(113.03229822864479,153.28399785035097,172.86200810554104,59.090318246325026,31.95800419126694,11.080948814259616),c(152.59078131517563,148.29574111670843,138.24530341720475,49.31818719429918,34.02745517275735,29.033638595902133),c(82.12870066183763,21.441576226252135,27.658964623002507,22.779976669998327,12.786630229245665,21.948148826475204),c(94.43886896427009,193.24674228303658,330.0780569239715,54.773525052444946,68.18782265159578,98.39952928664086),c(205.48319684734673,134.79930838749985,101.83276962576976,114.94189763279937,175.98824996972715,208.7283123585964),c(0.6788314773825342,0.5792560793770106,0.8232044938491284,0.5792560793770106,0.5792560793770106,0.5792560793770106),c(40.93013159383313,198.08466766241582,35.752886657621936,40.246780218724425,31.405044174016943,19.66963075185563))
targetgene="Cnot2"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(212.3252919870833,336.9175941178826,385.8718126999896,360.0327137568079,229.06583711937262,312.7974471900405),c(11.144814229620016,44.253527168846915,26.45002810928666,1.141066852381595,1.141066852381595,1.141066852381595),c(191.58949399190456,163.46950411663897,174.65866740407708,34.45229617475754,33.907207529376066,32.65341071777747),c(410.56332818001465,515.6415106742157,383.1376276801971,139.84949979616292,176.09084822579777,164.3412914475576),c(232.2168414484749,121.36129875983825,208.21066108740686,30.405390367049865,42.6834631937785,30.46321753138644))
targetgene="Arid4a"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(7.272980998195681,31.36395197007217,30.051605335430402,3.565854046314628,0.83256806608575,0.83256806608575),c(95.98874479483769,101.8353196708991,90.73075444277873,39.819846613782495,35.935315462323274,14.871679376985112),c(30.866904458704763,32.97207448345731,6.726026293280008,0.7712522633721273,0.7712522633721273,6.692551035104325),c(288.9138282946427,171.3215689134109,212.5084997004102,48.341405573073686,72.07443743517844,72.60026202992864),c(110.61238587485516,374.2161758343781,808.3841227323314,157.8960505961878,116.64356674922668,99.46688789779805))
targetgene="Fbxw7"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(268.2300048131619,323.69045600883965,444.4772933914028,83.11740280130071,96.82801096841949,85.31250404163129),c(419.4532470985087,205.16762358621125,187.5719608353512,77.39159868031575,85.64077122012678,72.71645862388289),c(115.82786171704538,95.83347129161672,56.40164371403028,29.52404182149062,17.625132618532692,27.07135159978531),c(87.67853740607946,78.40622338351645,33.54914112404714,1.9050920988638322,3.939568030757589,1.4723092857842108),c(130.60782090745766,57.1597069430127,113.95130056439226,51.683819833114654,28.532832980837743,21.065981595648427))
targetgene="Ralgapb"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(247.3867602933797,77.06722177333863,254.41622490461108,43.725506301669846,26.150671003388183,55.37174375849026),c(341.7366298625543,295.1646965785984,448.403265900821,120.38539342656114,122.96070656901732,98.81878893943411),c(158.366692739337,134.4426381691657,216.823811693508,53.18591319195795,59.39339447886209,65.66040102853559),c(31.971052832373136,55.21041739150329,79.21956060354135,38.706363661630604,81.93135125902002,39.13573252746395),c(351.1270612517184,296.5629364736998,344.90870647601315,119.88480742645609,91.67431124582731,102.0089863257251))
targetgene="Foxa2"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(137.35421401307272,151.65185359463166,152.28825673480372,40.334832880203145,69.87906938460684,94.14865427890714),c(61.49406044336546,87.08932837602633,81.73389019463765,4.48221530719889,3.3769989579402977,17.75419404471761),c(179.85421868515195,142.1079116860051,237.69238949066494,241.32259128706878,284.8180778311058,231.0134691505371),c(263.41086655015226,231.28677418560414,208.04624685066287,41.439122842589235,93.61638958959314,60.02660533906706),c(316.14631841736417,320.4657366708408,317.5062872280277,49.18145483616095,50.15466087596273,94.10006570007475))
targetgene="Slc33a1"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(249.26397753159748,369.0260986926619,362.89970830224496,143.1570165747303,230.88979531035343,231.2158064430445),c(225.31990068864698,143.04478338581958,121.27078049704818,43.061793961907696,46.75907466722711,12.165930699865005),c(878.8150504842455,777.7171834198466,416.3704123395128,149.3515446518778,118.6400840909147,159.76295877457065),c(411.6906379749221,460.0641427113046,443.19789594743065,93.50730700313966,125.03902941574054,130.8340083371466),c(427.34890715057634,182.9506614036879,167.35658618620917,259.4943299441897,201.5695422649823,230.57110612237608))
targetgene="Kdm2b"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(137.5362905722531,85.59974987077622,198.4744911806825,151.63735995572563,111.50066428845123,66.35806931502637),c(585.2176236735875,443.58124276454333,385.2081175560156,291.5907334212667,182.62308171194235,182.1634662268084),c(240.99818404462718,338.53714661905826,254.15407401322372,74.88983375736134,77.39189168733981,30.631751083249167),c(391.0213033693562,799.0090844078939,569.7585883548059,281.9089020214164,240.72784184997667,226.07889285874413),c(418.93252097601925,242.2428379839992,346.584906266997,179.97347646568718,206.28224266451676,131.50198318856295))
targetgene="Qrich1"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(411.11052984861476,572.7558150383447,503.14019111938364,161.94762957085754,169.50314651474113,139.52382317147175),c(854.5774249636834,1115.7603088516998,570.2779052761717,169.5872906577003,141.62264995334507,120.20722396049419),c(66.83981091098183,242.17028159551194,35.43080320773406,61.88532603056865,30.358956303146243,53.225896700412505),c(192.2001186957788,382.87245630581725,141.63223585360626,84.23086980035012,70.4160635951049,85.96652237623795),c(315.60510660340134,210.82864781964253,319.33706603117497,429.17561011083757,340.94491488723486,386.43175450296815),c(13.628633680702626,60.44031495377463,28.60194881244198,56.87349692349173,59.183674631947355,107.22469336182569))
targetgene="Cdkn2a"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}



# 
#
# parameters
# Do not modify the variables beginning with "__"

# gstablename='__GENE_SUMMARY_FILE__'
startindex=9
# outputfile='__OUTPUT_FILE__'
targetgenelist=c("Ube2m","Pfkl","Ogdh","Glrx5","Dlst","Sdhb","Sdha","Hira","Fosl1","Slc6a4")
# samplelabel=sub('.\\w+.\\w+$','',colnames(gstable)[startindex]);
samplelabel='ERS3957545.sample,ERS3957544.sample,ERS3957548.sample_vs_ERS3957541.sample,ERS3957543.sample,ERS3957542.sample pos.'


# You need to write some codes in front of this code:
# gstable=read.table(gstablename,header=T)
# pdf(file=outputfile,width=6,height=6)


# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")

######
# function definition

plotrankedvalues<-function(val, tglist, ...){
  
  plot(val,log='y',ylim=c(max(val),min(val)),type='l',lwd=2, ...)
  if(length(tglist)>0){
    for(i in 1:length(tglist)){
      targetgene=tglist[i];
      tx=which(names(val)==targetgene);ty=val[targetgene];
      points(tx,ty,col=colors[(i %% length(colors)) ],cex=2,pch=20)
      # text(tx+50,ty,targetgene,col=colors[i])
    }
    legend('topright',tglist,pch=20,pt.cex = 2,cex=1,col=colors)
  }
}



plotrandvalues<-function(val,targetgenelist, ...){
  # choose the one with the best distance distribution
  
  mindiffvalue=0;
  randval=val;
  for(i in 1:20){
    randval0=sample(val)
    vindex=sort(which(names(randval0) %in% targetgenelist))
    if(max(vindex)>0.9*length(val)){
      # print('pass...')
      next;
    }
    mindiffind=min(diff(vindex));
    if (mindiffind > mindiffvalue){
      mindiffvalue=mindiffind;
      randval=randval0;
      # print(paste('Diff: ',mindiffvalue))
    }
  }
  plot(randval,log='y',ylim=c(max(randval),min(randval)),pch=20,col='grey', ...)
  
  if(length(targetgenelist)>0){
    for(i in 1:length(targetgenelist)){
      targetgene=targetgenelist[i];
      tx=which(names(randval)==targetgene);ty=randval[targetgene];
      points(tx,ty,col=colors[(i %% length(colors)) ],cex=2,pch=20)
      text(tx+50,ty,targetgene,col=colors[i])
    }
  }
  
}




# set.seed(1235)



pvec=gstable[,startindex]
names(pvec)=gstable[,'id']
pvec=sort(pvec);

plotrankedvalues(pvec,targetgenelist,xlab='Genes',ylab='RRA score',main=paste('Distribution of RRA scores in \\n',samplelabel))

# plotrandvalues(pvec,targetgenelist,xlab='Genes',ylab='RRA score',main=paste('Distribution of RRA scores in \\n',samplelabel))


pvec=gstable[,startindex+1]
names(pvec)=gstable[,'id']
pvec=sort(pvec);

plotrankedvalues(pvec,targetgenelist,xlab='Genes',ylab='p value',main=paste('Distribution of p values in \\n',samplelabel))

# plotrandvalues(pvec,targetgenelist,xlab='Genes',ylab='p value',main=paste('Distribution of p values in \\n',samplelabel))



# you need to write after this code:
# dev.off()






# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(72.1089350240923,69.79681105498719,65.47664939908658,187.20965892419045,187.76879685457718,235.07681163154186),c(95.74419927507321,45.185108376046955,46.12259120898571,287.83883663085544,226.8360552032098,236.1499960884973),c(38.401846434524344,32.657306135428435,90.50419365482448,509.2332848685714,418.49825163636376,394.9262051803025),c(13.595671245103075,22.924852201006665,24.98499059922222,126.64257031048996,177.94104298492337,175.14289459294974),c(2.282388415479893,1.3642512901030415,0.8828543294569408,42.972113794033866,25.503125381664493,16.18720423238324),c(127.87467462452057,110.96906625806425,143.48876182234295,270.60091688655876,266.2429651971795,265.4305418709021),c(39.70438344670392,32.85322080086502,49.7092135388416,214.18343223582394,192.05306004890576,290.1092016633842),c(15.672293181452789,9.280980431405167,19.642798199271507,258.60549786274737,248.94941753643866,213.23066341869023))
targetgene="Ube2m"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(86.34395631926941,103.48775169888418,101.24398308881544,585.31443941418,552.1019898160249,509.4220590270037),c(94.14675523772274,97.08934940887151,59.894875296057506,580.4902445717917,589.7385099981067,604.1828647493165),c(25.803015602644543,23.54161389473652,33.44113487928816,359.04853992931925,333.6848881129209,360.7093851311289),c(40.52291961378405,36.12704745509064,32.58093339096449,168.89462922689708,183.10907273708858,157.32023282536622),c(14.664114681196306,32.01722918622247,13.644748549054082,201.64424379463327,183.41511836117337,215.24225255696646))
targetgene="Pfkl"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(50.89291294552181,31.054396474146326,37.351510849774925,145.5732015568082,91.72408302549796,148.77990594451768),c(63.647491652770285,80.66013006738834,79.18776129827724,444.6569394582438,422.49903998284765,303.38330565584164),c(15.328348241333236,11.000050407901918,8.032675688793713,208.72743262673077,189.26920165299035,235.73585213677777),c(18.523208081765116,16.820436750765413,58.385497792028616,215.97413865777597,278.73468024050857,211.83660569656294),c(45.93738537087657,25.127337425135643,41.59557513890684,331.95907684784464,325.9747286558222,281.45513698390175))
targetgene="Ogdh"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(66.76868760862386,91.73320636916236,97.38674169202697,552.2587849487072,503.7148520521226,486.21261446515075),c(35.79090849380016,35.65412881811442,48.80791736107205,210.2065001569307,217.29714913167132,324.1593899757088),c(35.064599333663615,19.199948973424746,44.97700695604602,165.14061554255227,155.87708468949162,158.531438317889),c(28.864320386968338,44.13472672396365,33.29940586743875,253.9475329718241,284.4254578005011,206.28146404748847),c(0.8437448728568323,2.5253251629721336,0.5319622605629802,53.65665179864855,44.62544340138529,40.75794424829614))
targetgene="Glrx5"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(59.65155494102256,29.741373650389427,41.933819801823326,190.2768872864559,298.9371338561235,197.9398187303977),c(108.40516447901308,110.96602201416789,199.66686303914344,161.0596381862657,231.16265139002246,208.8341117589118),c(42.75426023562432,15.464821517980353,19.995425676220936,145.9682752455119,118.99722665413633,148.61276013010723),c(50.69251915900488,34.58032359806265,67.08478504549635,353.79464654652026,305.5519642290416,386.6591923243283),c(39.41899833726691,43.380452624984734,46.80446416279957,277.3961869671591,229.00782872025576,229.0134326941122))
targetgene="Dlst"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(74.82542255273202,42.128061038086564,51.20528437179924,296.8818664132802,255.22200881530455,277.1818219178746),c(94.765782067497,43.82274309449829,72.28232744507007,136.6913002267872,128.9066128480211,156.41779611540215),c(22.57482626797031,27.47436028926169,22.185310679638633,119.40684430781639,112.85764558170723,107.86423290633971),c(41.59168980090878,74.06719247153897,58.295031680646446,263.80021707420644,324.84062225608056,313.1839464535436),c(82.00711548066822,95.73014308951967,47.13495906235613,302.7494931095432,277.11349964566426,292.7527221194147))
targetgene="Sdhb"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(35.197629925358626,36.6918584782488,42.73696392319477,25.748346678271826,38.78436700733847,30.789090808471606),c(77.6795107040327,135.33977930367323,92.66060747944536,413.1538512399444,501.2963010810274,502.8312229313942),c(26.97415563198372,10.451748458744088,23.04934460826544,225.56535033571953,181.3007212278069,221.7284863807582),c(127.79328070480437,109.73359197850304,264.40288829445694,294.85437176719483,386.77280987985023,490.3218536750977),c(37.9648971438521,47.397548554669704,86.4828875726803,243.98644501911278,227.98870820089562,205.7911437933826))
targetgene="Sdha"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(381.73725880805057,155.13504145970757,140.92074059345643,697.8939812236955,714.5215461326977,528.174742337454),c(189.04901819129245,62.774528788679554,122.13094046453904,540.3642374875857,495.0270106497138,633.865398335382),c(109.13211152479357,64.60952830683921,43.493795464693086,176.0996931555729,97.75230182702157,194.29902012158922),c(65.53013008941859,31.20222064195636,45.642451157923176,313.7959218102014,244.03784241898526,283.6482262206251),c(178.82207689595245,110.72343814880942,204.35172940052223,363.43748249081534,366.07033352157845,448.78693070838824))
targetgene="Hira"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(57.588031588719275,26.918876787353042,87.5671622918014,275.0425647993353,293.80763836128193,215.86383589075817),c(37.193114830259155,46.48258213786868,21.772740771643434,108.53774416516951,66.40121087914454,108.7730882641936),c(17.569141111221267,7.153438427183053,15.284943784603778,70.06699901943699,70.299242256349,36.65418302163166),c(81.09320271420687,96.62306293263829,106.53670195676509,264.3690677973856,243.65807877885246,212.12655904172252),c(10.66651196177465,11.020631268401608,23.585891940159726,104.02424782307122,162.93603785519244,163.17592536945918))
targetgene="Fosl1"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(62.87750191883242,13.877973648669983,71.84637407975308,273.79037487306607,347.7959505412568,323.6824386161265),c(120.99932174268433,195.29618607560784,98.05346674886113,151.54309651610916,95.13013125145014,165.68777325698505),c(96.18240675398877,149.64687471625473,166.6107863347679,657.3856185779781,611.9957138983314,495.0921925168298),c(48.892049894860484,50.53077510241498,95.20219560778914,251.4900305403384,266.3531507073601,249.22279501077693),c(127.64981695240239,51.04189510559051,38.424796815096485,183.2235374969759,181.6124495864738,72.11627055453448))
targetgene="Slc6a4"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957545.sample","ERS3957544.sample","ERS3957548.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}



dev.off()
Sweave("cl1_vs_flfl_summary.Rnw");
library(tools);

texi2dvi("cl1_vs_flfl_summary.tex",pdf=TRUE);

