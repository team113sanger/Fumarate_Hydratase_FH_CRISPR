pdf(file='pFH_vs_flfl.pdf',width=4.5,height=4.5);
gstable=read.table('pFH_vs_flfl.gene_summary.txt',header=T)
# 
#
# parameters
# Do not modify the variables beginning with "__"

# gstablename='__GENE_SUMMARY_FILE__'
startindex=3
# outputfile='__OUTPUT_FILE__'
targetgenelist=c("Ambra1","Kdm1a","Errfi1","Cdkn2a","Sowahd","Zfp191","Rock2","Zeb1","Arhgef16","Sin3b")
# samplelabel=sub('.\\w+.\\w+$','',colnames(gstable)[startindex]);
samplelabel='ERS3957547.sample,ERS3957546.sample,ERS3957549.sample_vs_ERS3957541.sample,ERS3957543.sample,ERS3957542.sample neg.'


# You need to write some codes in front of this code:
# gstable=read.table(gstablename,header=T)
# pdf(file=outputfile,width=6,height=6)


# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")

######
# function definition

plotrankedvalues<-function(val, tglist, ...){
  
  plot(val,log='y',ylim=c(max(val),min(val)),type='l',lwd=2, ...)
  if(length(tglist)>0){
    for(i in 1:length(tglist)){
      targetgene=tglist[i];
      tx=which(names(val)==targetgene);ty=val[targetgene];
      points(tx,ty,col=colors[(i %% length(colors)) ],cex=2,pch=20)
      # text(tx+50,ty,targetgene,col=colors[i])
    }
    legend('topright',tglist,pch=20,pt.cex = 2,cex=1,col=colors)
  }
}



plotrandvalues<-function(val,targetgenelist, ...){
  # choose the one with the best distance distribution
  
  mindiffvalue=0;
  randval=val;
  for(i in 1:20){
    randval0=sample(val)
    vindex=sort(which(names(randval0) %in% targetgenelist))
    if(max(vindex)>0.9*length(val)){
      # print('pass...')
      next;
    }
    mindiffind=min(diff(vindex));
    if (mindiffind > mindiffvalue){
      mindiffvalue=mindiffind;
      randval=randval0;
      # print(paste('Diff: ',mindiffvalue))
    }
  }
  plot(randval,log='y',ylim=c(max(randval),min(randval)),pch=20,col='grey', ...)
  
  if(length(targetgenelist)>0){
    for(i in 1:length(targetgenelist)){
      targetgene=targetgenelist[i];
      tx=which(names(randval)==targetgene);ty=randval[targetgene];
      points(tx,ty,col=colors[(i %% length(colors)) ],cex=2,pch=20)
      text(tx+50,ty,targetgene,col=colors[i])
    }
  }
  
}




# set.seed(1235)



pvec=gstable[,startindex]
names(pvec)=gstable[,'id']
pvec=sort(pvec);

plotrankedvalues(pvec,targetgenelist,xlab='Genes',ylab='RRA score',main=paste('Distribution of RRA scores in \\n',samplelabel))

# plotrandvalues(pvec,targetgenelist,xlab='Genes',ylab='RRA score',main=paste('Distribution of RRA scores in \\n',samplelabel))


pvec=gstable[,startindex+1]
names(pvec)=gstable[,'id']
pvec=sort(pvec);

plotrankedvalues(pvec,targetgenelist,xlab='Genes',ylab='p value',main=paste('Distribution of p values in \\n',samplelabel))

# plotrandvalues(pvec,targetgenelist,xlab='Genes',ylab='p value',main=paste('Distribution of p values in \\n',samplelabel))



# you need to write after this code:
# dev.off()






# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(322.50803614814754,273.94658934908745,295.5403304557416,110.65481207013083,118.89663192721193,104.72346344394293),c(482.21156080084035,315.3537023158537,585.4350961426373,99.43445633237377,98.67864782385963,111.7717892318302),c(219.8993628980414,281.3557090625103,266.7133701139282,125.99998591820163,121.55016669844323,162.9549360186859),c(355.6820922255935,300.32239491602553,399.9136620888929,200.61991965741734,201.80697103452056,226.47290289769737),c(314.2864621811389,448.4579412269907,360.4876785370207,176.84390525586102,198.84541752326052,188.75997797654946))
targetgene="Ambra1"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957547.sample","ERS3957546.sample","ERS3957549.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(284.59612787258953,406.33562940258037,132.1715460376787,74.90285021261573,73.4315863566546,154.77967984978514),c(511.813860640699,287.36753556129815,592.7069321382551,142.67541382260742,235.32005781566443,282.05436799289475),c(470.0216408657581,364.42373885047436,489.78207896772403,202.50256469358854,275.0654226174347,290.3018482968325),c(406.3509811056264,410.3420016988825,425.5293902780177,162.5699104880076,118.7839553335275,97.24654153815736),c(336.49202432700156,277.79365874378266,551.9105586842588,272.6660020820109,253.610232341699,218.75424528740535))
targetgene="Kdm1a"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957547.sample","ERS3957546.sample","ERS3957549.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(272.0738366999735,343.830741419996,422.02523311358726,201.9337088218348,182.966973596112,237.9392616771119),c(375.4912676199789,324.98222125015326,371.5586438643241,230.93158779135544,280.6339782753428,235.07318219829764),c(44.37782405186669,74.86413465091763,91.72844604713953,33.548667655313125,17.07319634318939,41.38518392480721),c(406.54795744015513,249.21252097048608,236.22200858920058,167.59513865319715,146.8343760783291,149.4183600744335),c(73.24790750002911,79.26730472153689,69.50260806700999,33.34966013011364,32.406853768888965,46.114640467367956))
targetgene="Errfi1"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957547.sample","ERS3957546.sample","ERS3957549.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(411.11052984861476,572.7558150383447,503.14019111938364,170.93677224796258,157.8217718809342,225.19920318100253),c(854.5774249636834,1115.7603088516998,570.2779052761717,267.8693413023997,289.80783309344287,281.1468196849836),c(66.83981091098183,242.17028159551194,35.43080320773406,42.74185147060834,83.13090481440976,76.86800180633844),c(192.2001186957788,382.87245630581725,141.63223585360626,92.46917993066266,122.08405761517166,118.22372474090656),c(315.60510660340134,210.82864781964253,319.33706603117497,191.43922937000576,154.10817603237527,155.45602683975105),c(13.628633680702626,60.44031495377463,28.60194881244198,72.98567368926732,27.261795822093934,36.62709434613241))
targetgene="Cdkn2a"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957547.sample","ERS3957546.sample","ERS3957549.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(123.64673183831877,106.23291662926803,146.379568040853,51.311689261656,74.19645968119796,75.03941690169),c(207.1490322099108,420.3065810292686,355.9733195559187,251.95724641348673,216.4531201378987,232.69948444624262),c(330.45296679481396,315.2707662261172,179.0108111554701,157.41132990726825,173.11083320073664,224.00888224316898),c(224.54469656524847,410.7612209951734,537.6422675870356,361.15220910435204,266.5053322573661,282.9373647598213),c(236.1459380023399,276.93551303105096,279.1395773984415,142.66127635496719,172.46621402465988,166.06206000071336))
targetgene="Sowahd"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957547.sample","ERS3957546.sample","ERS3957549.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(104.66438736200134,153.5039750284012,54.535291064535734,101.93464590885617,90.16241433971052,143.19422858324907),c(219.14430645213207,231.8275200981894,417.96641828419314,334.0922643688431,274.12522066273954,407.62878809306795),c(371.89497795732086,623.8236095488238,220.62531968939268,339.14908850934506,287.71976739374713,293.78526886042914),c(148.52323093675625,356.63995393299643,974.3567476109083,119.2360152994169,124.86693838664469,225.3029881648895),c(97.81662623093392,341.35267545396243,368.672107510257,62.87450420462134,67.81057448207828,148.9411406945209))
targetgene="Zfp191"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957547.sample","ERS3957546.sample","ERS3957549.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(402.2511625316451,282.41691795131305,526.5664791232746,125.61953139624549,203.11684295027516,252.8165098727003),c(334.34979107865365,289.56068484721476,278.37412106143785,144.14556836800745,198.61828199902743,159.35754428638538),c(428.03649346316075,431.007269386068,453.1475858730819,325.0181924870517,286.27206053394485,408.7867440389885),c(100.73469283912137,147.63784918196805,123.67503815185414,61.428438380052775,69.25057464344951,84.06687843513663),c(263.86988653251075,203.6767317209301,281.8836283869729,130.16978609106422,121.59746571251372,200.00526572755032))
targetgene="Rock2"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957547.sample","ERS3957546.sample","ERS3957549.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(452.236750373475,386.7765148230099,424.5488639722664,237.69903548427237,298.65460383862404,248.49522160312384),c(725.1173632603285,296.2237394574763,983.2152567387277,210.89685291048522,207.50394570536096,191.1259253517544),c(76.4147678960477,44.26180498585551,86.23905137441508,84.92822636573736,100.25639939726997,67.72448058551655),c(240.98276182485208,195.8170859521081,233.12929082404338,96.5852310813757,111.45585628862756,161.22086107637577),c(199.59620593729693,270.7652145802989,515.0033370344973,164.22145061872473,162.33501778737363,166.4796422607205))
targetgene="Zeb1"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957547.sample","ERS3957546.sample","ERS3957549.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(239.4531261010671,145.2321051894504,137.24868444096768,131.45706894285837,190.98351469203865,167.86703577852282),c(381.8740033667208,154.68279964205334,407.35312817219045,130.72992664029545,134.18632780938276,114.46525913337965),c(324.5007702329382,241.11824648848753,159.37546940354116,84.35531929746462,72.82241921725367,68.56949443499425),c(65.09494193345985,75.60550728961573,143.3679949340692,92.21757753717773,97.04192329330952,98.22925888671632),c(115.92764393030852,174.88826552482894,162.57628682956732,110.47013031267423,128.53775173676289,67.96887907016473))
targetgene="Arhgef16"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957547.sample","ERS3957546.sample","ERS3957549.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(493.91495647288417,204.424182043396,460.4381531772304,296.2520332915913,191.6850624597146,233.60684858147556),c(179.78580082276412,199.62353464215963,444.3871345483119,127.00899904256897,93.25214421536315,102.11660461930619),c(105.74243521821624,253.828119860623,121.11615511462162,134.00436666206738,72.41286679222651,76.23950812391396),c(339.16285363080476,278.2169067799281,132.66253750400182,150.28199524826533,178.04436655494007,199.55997212986395),c(118.07500199881821,150.73761467460758,173.50778505049834,75.43204498999124,103.44453937368212,120.81416083969226))
targetgene="Sin3b"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957547.sample","ERS3957546.sample","ERS3957549.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}



# 
#
# parameters
# Do not modify the variables beginning with "__"

# gstablename='__GENE_SUMMARY_FILE__'
startindex=9
# outputfile='__OUTPUT_FILE__'
targetgenelist=c("Hspa9","Tubb5","Fau","Phb2","Prc1","Pcna","Eif3g","Rpl13a","Wdr55","Dbr1")
# samplelabel=sub('.\\w+.\\w+$','',colnames(gstable)[startindex]);
samplelabel='ERS3957547.sample,ERS3957546.sample,ERS3957549.sample_vs_ERS3957541.sample,ERS3957543.sample,ERS3957542.sample pos.'


# You need to write some codes in front of this code:
# gstable=read.table(gstablename,header=T)
# pdf(file=outputfile,width=6,height=6)


# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")

######
# function definition

plotrankedvalues<-function(val, tglist, ...){
  
  plot(val,log='y',ylim=c(max(val),min(val)),type='l',lwd=2, ...)
  if(length(tglist)>0){
    for(i in 1:length(tglist)){
      targetgene=tglist[i];
      tx=which(names(val)==targetgene);ty=val[targetgene];
      points(tx,ty,col=colors[(i %% length(colors)) ],cex=2,pch=20)
      # text(tx+50,ty,targetgene,col=colors[i])
    }
    legend('topright',tglist,pch=20,pt.cex = 2,cex=1,col=colors)
  }
}



plotrandvalues<-function(val,targetgenelist, ...){
  # choose the one with the best distance distribution
  
  mindiffvalue=0;
  randval=val;
  for(i in 1:20){
    randval0=sample(val)
    vindex=sort(which(names(randval0) %in% targetgenelist))
    if(max(vindex)>0.9*length(val)){
      # print('pass...')
      next;
    }
    mindiffind=min(diff(vindex));
    if (mindiffind > mindiffvalue){
      mindiffvalue=mindiffind;
      randval=randval0;
      # print(paste('Diff: ',mindiffvalue))
    }
  }
  plot(randval,log='y',ylim=c(max(randval),min(randval)),pch=20,col='grey', ...)
  
  if(length(targetgenelist)>0){
    for(i in 1:length(targetgenelist)){
      targetgene=targetgenelist[i];
      tx=which(names(randval)==targetgene);ty=randval[targetgene];
      points(tx,ty,col=colors[(i %% length(colors)) ],cex=2,pch=20)
      text(tx+50,ty,targetgene,col=colors[i])
    }
  }
  
}




# set.seed(1235)



pvec=gstable[,startindex]
names(pvec)=gstable[,'id']
pvec=sort(pvec);

plotrankedvalues(pvec,targetgenelist,xlab='Genes',ylab='RRA score',main=paste('Distribution of RRA scores in \\n',samplelabel))

# plotrandvalues(pvec,targetgenelist,xlab='Genes',ylab='RRA score',main=paste('Distribution of RRA scores in \\n',samplelabel))


pvec=gstable[,startindex+1]
names(pvec)=gstable[,'id']
pvec=sort(pvec);

plotrankedvalues(pvec,targetgenelist,xlab='Genes',ylab='p value',main=paste('Distribution of p values in \\n',samplelabel))

# plotrandvalues(pvec,targetgenelist,xlab='Genes',ylab='p value',main=paste('Distribution of p values in \\n',samplelabel))



# you need to write after this code:
# dev.off()






# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(61.39815587497415,89.95928289402252,56.50456640552344,302.4359873349693,193.85912773531732,255.76632415327103),c(34.98986307798149,27.198469923278644,140.23370277753105,158.05539313417498,202.79732105904054,214.00440511069885),c(149.39982706922012,171.98471061555625,218.58652740441084,543.2234152507187,630.5320636563947,401.46900245920483),c(19.258862623460885,16.47688501136977,55.296682169894616,214.42180763869928,101.67389834522108,95.41440656839548),c(2.4359674307114516,9.010050082871214,4.829700182708488,13.91610653437532,73.83126476091122,70.3222974570713))
targetgene="Hspa9"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957547.sample","ERS3957546.sample","ERS3957549.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(21.8315801886833,10.160024029726834,13.055367250990278,79.95447535181472,34.625287321724755,67.9001710437642),c(4.125652949042514,13.970033040874396,8.001676702219848,51.35287441295417,58.072332279743094,21.70957849698583),c(7.047990454614294,1.9050045055737812,9.545859925455256,71.6665114433949,49.21153040607337,43.11121971032647),c(5.500870598723351,9.048771401475461,3.7902679115778226,59.15331103264341,33.26208703346788,36.49056811195491),c(22.003482394893403,49.68886752038279,22.881987762488336,102.21822153717777,96.51458040858712,109.00979841039695))
targetgene="Tubb5"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957547.sample","ERS3957546.sample","ERS3957549.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(140.75007971211926,14.263122832491504,38.17925129993156,240.17775039231887,245.86304263732848,294.2327548113802),c(227.50926326424084,75.43317470337277,215.45716481459888,524.38304564968,616.3067506800394,356.1830127677235),c(202.21794612572515,71.34488472033321,93.88629591600142,395.55165311815125,486.35147615056286,657.5910341240215),c(30.369162851869447,49.69795856850914,84.24651860031969,172.34295547260461,228.0992469859066,150.56714598519864),c(79.79663545319545,146.15924233515156,288.19178709023186,645.418971532113,548.3966377742925,502.71429601489524))
targetgene="Fau"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957547.sample","ERS3957546.sample","ERS3957549.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(112.02289913706895,51.85740937175898,77.90126363934249,430.4479648677483,363.72930122442745,230.9411646713978),c(129.95619864151882,81.91263781303611,28.607571108360723,327.8080992865059,322.6323099945386,318.4421244708227),c(29.01846210752284,46.025225899633206,40.21745962170363,94.49330739049762,157.34795709620232,106.3137301419488),c(9.811036301516072,10.33671230288857,3.556471523944183,78.16850199212251,74.1743598887938,82.71651886614009),c(84.60591066031019,58.5728796404935,53.96064213403299,339.6818661393144,399.82704058164217,253.4562459678716))
targetgene="Phb2"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957547.sample","ERS3957546.sample","ERS3957549.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(3.2661419179919897,3.333757884754117,0.0,10.56309125582918,22.901764842715586,22.171484422453617),c(5.500870598723351,26.03506157617501,24.145410399680944,101.56818515220367,90.10753905377977,128.40984728004386),c(16.158807383749842,31.591324717431874,15.582212525375493,95.88036678368026,117.78050490539445,154.27657910623972),c(15.29929635269932,28.41631720814224,16.143733697461098,66.79123855608913,67.75105432636694,56.5064915488922),c(28.020059612247067,27.146314204426382,3.0883664464708183,115.70647652539041,99.92258112922931,101.00342903562203))
targetgene="Prc1"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957547.sample","ERS3957546.sample","ERS3957549.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(0.6148447533091593,4.128690829156205,11.74910392886434,38.583633525640295,60.37540640783607,25.133548957387863),c(0.6346120982858733,2.6495102758295728,0.6346120982858733,11.56641738539623,8.59356333518025,15.095745801160769),c(1.6782483113926763,0.24519035727194977,0.24519035727194977,13.195030951836776,8.935523065756113,3.718339976610562),c(30.225105008027466,5.601880519650803,11.86423229416392,44.81965840652358,112.7750310430848,39.46989050902277),c(94.19966042872215,20.05659042878724,33.760257777408846,170.24766266132528,188.25716172123165,166.76790195048474))
targetgene="Pcna"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957547.sample","ERS3957546.sample","ERS3957549.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(8.251305898085027,18.57379392934437,5.615211720856034,78.97942077435357,36.94272781176145,66.51445326736085),c(33.864734623390625,9.842523278797868,45.62359523195527,110.018658156867,112.32770375236693,70.36366931292572),c(13.064567671967959,7.937518773224088,2.667225567406616,78.16687529313594,70.61377493170639,46.34456118860096),c(17.705927239640786,28.257566832677757,13.616888423075881,42.7398923120473,100.33154121570638,146.42417837328742),c(12.892665465757853,12.382529286229579,56.99439896668874,70.85396596217727,68.29633444166969,97.15421299005716))
targetgene="Eif3g"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957547.sample","ERS3957546.sample","ERS3957549.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(11.68935002228712,6.667515769508234,72.71699178508563,50.215310739249496,140.95490980576142,62.357299938150796),c(6.876088248404189,0.31750075092896357,5.334451134813232,43.06491050453435,56.43649193383484,76.21447770218431),c(3.9537507428324083,18.73254430480885,84.22817581284049,115.0564401404163,80.56513703598162,144.8844919550615),c(0.0,0.0,0.0,9.913054870855078,0.817920172954128,4.003184687387458),c(50.71115083198089,36.83008710775977,13.897649009118682,116.03149471787746,134.68418847977975,64.82079820731231))
targetgene="Rpl13a"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957547.sample","ERS3957546.sample","ERS3957549.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(63.200825407866105,10.508939316245979,53.296413691355966,165.8151988232867,165.55757535628456,218.3935174107487),c(20.299085355902882,49.088742303193506,26.077345471633606,152.6393201471621,124.80948248377703,49.628743137767636),c(33.77899093545085,74.47266822929232,80.17678471703265,215.99304767213258,198.94551117797727,228.69049752785233),c(13.292647085775164,28.829475607176086,9.562600094887774,102.7945822189743,118.45425788765503,106.19189649713218),c(101.83858040193523,104.878472453546,68.44057095754317,252.2298305198659,162.86090575147546,287.2242146789454))
targetgene="Wdr55"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957547.sample","ERS3957546.sample","ERS3957549.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}




# parameters
# Do not modify the variables beginning with "__"
targetmat=list(c(54.32109716239309,42.38635024901664,116.7964037938055,141.70793192435454,68.02369438401833,110.85742211226808),c(33.864734623390625,13.49378191448095,10.388141683583662,170.9595692481892,132.50306801856877,92.68912237720193),c(4.985163980093037,0.0,0.0,18.688546068005476,18.403203891467882,13.703209122210916),c(0.0,0.0,2.2460846883424135,9.588036678368026,3.271680691816512,6.620651598371565),c(11.68935002228712,45.402607382841786,16.424494283503897,31.039237382513438,51.528970896110074,137.18605986393175))
targetgene="Dbr1"
collabel=c("ERS3957541.sample","ERS3957543.sample","ERS3957542.sample","ERS3957547.sample","ERS3957546.sample","ERS3957549.sample")

# set up color using RColorBrewer
#library(RColorBrewer)
#colors <- brewer.pal(length(targetgenelist), "Set1")

colors=c( "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",  "#A65628", "#F781BF",
          "#999999", "#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3", 
          "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
          "#D9D9D9", "#BC80BD", "#CCEBC5", "#FFED6F")


## code

targetmatvec=unlist(targetmat)+1
yrange=range(targetmatvec[targetmatvec>0]);
# yrange[1]=1; # set the minimum value to 1
for(i in 1:length(targetmat)){
  vali=targetmat[[i]]+1;
  if(i==1){
    plot(1:length(vali),vali,type='b',las=1,pch=20,main=paste('sgRNAs in',targetgene),ylab='Read counts',xlab='Samples',xlim=c(0.7,length(vali)+0.3),ylim = yrange,col=colors[(i %% length(colors))],xaxt='n',log='y')
    axis(1,at=1:length(vali),labels=(collabel),las=2)
    # lines(0:100,rep(1,101),col='black');
  }else{
    lines(1:length(vali),vali,type='b',pch=20,col=colors[(i %% length(colors))])
  }
}



dev.off()
Sweave("pFH_vs_flfl_summary.Rnw");
library(tools);

texi2dvi("pFH_vs_flfl_summary.tex",pdf=TRUE);

